let express = require("express");

// express returns a function, we can call it to create a server object
let app = express();

let port = 3000;
let hostname = "localhost";

// app.use(express.json());

// middleware just for debugging
app.use("*", (req, res, next) => {
  console.log({ url: req.url, body: req.body });
  // makes sure next matching request handler is called
  // necessary b/c this doesn't send a response
  next();
});

app.post("/flargle", (req, res) => {
  console.log("You sent the body:", req.body);
  res.json();
});

app.get("/visitors/:visitorName", (req, res) => {
  let visitorName = req.params.visitorName;
  console.log(req.params, visitorName);
  res.json();
});
app.post("/visitors/:visitorName", (req, res) => {
  let visitorName = req.params.visitorName;
  console.log(req.params, visitorName);
  res.json();
});

app.listen(port, hostname, () => {
  console.log(`Listening at: http://${hostname}:${port}`);
});
