console.log("This is script.js");
